int main(int ari,char **arc){
	short sh;
	printf("hello word\n");
	return 0;
}
